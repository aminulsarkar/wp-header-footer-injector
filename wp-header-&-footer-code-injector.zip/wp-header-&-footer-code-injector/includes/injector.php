<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Inject header code
 */
add_action( 'wp_head', function () {

    if ( is_admin() ) {
        return;
    }

    $settings = get_option( 'wp_hfi_settings' );

    // Check if plugin is enabled
    if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) {
        return;
    }

    if ( ! empty( $settings['header'] ) ) {
        echo "\n<!-- WP Header Injector -->\n";
        echo $settings['header'];
    }
});

/**
 * Inject body open code
 */
add_action( 'wp_body_open', function () {

    if ( is_admin() ) {
        return;
    }

    $settings = get_option( 'wp_hfi_settings' );

    // Check if plugin is enabled
    if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) {
        return;
    }

    if ( ! empty( $settings['body_open'] ) ) {
        echo "\n<!-- WP Body Open Injector -->\n";
        echo $settings['body_open'];
    }
});


/**
 * Inject footer code
 */
add_action( 'wp_footer', function () {

    if ( is_admin() ) {
        return;
    }

    $settings = get_option( 'wp_hfi_settings' );

    // Check if plugin is enabled
    if ( empty( $settings['enabled'] ) || $settings['enabled'] !== '1' ) {
        return;
    }

    if ( ! empty( $settings['footer'] ) ) {
        echo "\n<!-- WP Footer Injector -->\n";
        echo $settings['footer'];
    }
});
