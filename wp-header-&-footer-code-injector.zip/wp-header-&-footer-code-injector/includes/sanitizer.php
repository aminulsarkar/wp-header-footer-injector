<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Sanitize header & footer scripts
 */
function wp_hfi_sanitize_settings( $input ) {

    $allowed_tags = [
        'script' => [
            'type'   => true,
            'src'    => true,
            'async'  => true,
            'defer'  => true,
        ],
        'style' => [],
        'noscript' => [],
        'meta' => [
            'name'    => true,
            'content' => true,
        ],
        'link' => [
            'rel'  => true,
            'href'=> true,
        ],
    ];

    return [
        'enabled'   => isset( $input['enabled'] ) ? '1' : '0',
        'header'    => $input['header'] ?? '',
        'body_open' => $input['body_open'] ?? '',
        'footer'    => $input['footer'] ?? '',
    ];

}

