<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Register settings
add_action( 'admin_init', function () {

    register_setting(
        'wp_hfi_settings_group',
        'wp_hfi_settings',
        'wp_hfi_sanitize_settings'
    );
});

// Add menu
add_action('admin_menu', function() {
    add_menu_page(
        __('Header & Footer Injector', 'wp-hfi'),   // Page title
        __('Header & Footer', 'wp-hfi'),           // Menu title in sidebar
        'manage_options',                        // Capability
        'header-footer-injector',                // Menu slug
        'wp_hfi_settings_page',                  // Callback function
        'dashicons-editor-code',                 // Icon (WordPress Dashicon)
        60                                       // Position in menu
    );
});


// Admin page HTML
function wp_hfi_settings_page() {

    $settings = get_option( 'wp_hfi_settings', [] );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'WP Header & Footer Code Injector', 'wp-hfi' ); ?></h1>
        <p><?php esc_html_e( 'Add custom scripts like Google Analytics, Facebook Pixel, or custom CSS safely.', 'wp-hfi' ); ?></p>

        <form method="post" action="options.php">
            <?php settings_fields( 'wp_hfi_settings_group' ); ?>

            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e( 'Enable Injection', 'wp-hfi' ); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="wp_hfi_settings[enabled]" value="1"
                            <?php checked( $settings['enabled'] ?? '', '1' ); ?>>
                            <?php esc_html_e( 'Enable Header & Footer code injection', 'wp-hfi' ); ?>
                        </label>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php esc_html_e( 'Header Code', 'wp-hfi' ); ?></th>
                    <td>
                        <?php 
                        $header_placeholder = __("<!-- JavaScript Code -->\n<script>\nconsole.log('Header injector working');\n</script>\n\n<!-- CSS Code -->\n<style>\ndiv {\n    width: 50%;\n}\n</style>", 'wp-hfi');
                        ?>
                        <textarea 
                        placeholder="<?php echo esc_attr( $header_placeholder ); ?>" name="wp_hfi_settings[header]" rows="8" class="large-text code"><?php
                        echo esc_textarea( $settings['header'] ?? '' );
                        ?></textarea>
                        <p class="description"><?php esc_html_e( 'Injected inside', 'wp-hfi' ); ?> &lt;head&gt;</p>
                    </td>
                </tr>
                
                <tr>
    <th scope="row"><?php esc_html_e( 'Body Open Code', 'wp-hfi' ); ?></th>
    <td>
        <?php 
        $body_placeholder = __("<!-- Code after <body> -->\n<script>\nconsole.log('Body open injector working');\n</script>", 'wp-hfi');
        ?>
        <textarea 
        placeholder="<?php echo esc_attr( $body_placeholder ); ?>" 
        name="wp_hfi_settings[body_open]" 
        rows="8" 
        class="large-text code"><?php
        echo esc_textarea( $settings['body_open'] ?? '' );
        ?></textarea>
        <p class="description">
            <?php esc_html_e( 'Injected right after', 'wp-hfi' ); ?> &lt;body&gt;
        </p>
    </td>
</tr>


                <tr>
                    <th scope="row"><?php _e( 'Footer Code', 'wp-hfi' ); ?></th>
                    <td>
                        <?php 
                        $footer_placeholder = __("<!-- JavaScript Code -->\n<script>\nconsole.log('Footer injector working');\n</script>", 'wp-hfi');
                        ?>
                        <textarea placeholder="<?php echo esc_attr( $footer_placeholder ); ?>" name="wp_hfi_settings[footer]" rows="8" class="large-text code"><?php
                        echo esc_textarea( $settings['footer'] ?? '' );
                        ?></textarea>
                        <p class="description"><?php esc_html_e( 'Injected before', 'wp-hfi' ); ?> &lt;/body&gt;</p>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
